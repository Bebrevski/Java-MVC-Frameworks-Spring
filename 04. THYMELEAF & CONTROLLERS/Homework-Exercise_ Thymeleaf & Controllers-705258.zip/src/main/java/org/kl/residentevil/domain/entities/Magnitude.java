package org.kl.residentevil.domain.entities;

public enum Magnitude {
    Low, Medium, High
}
