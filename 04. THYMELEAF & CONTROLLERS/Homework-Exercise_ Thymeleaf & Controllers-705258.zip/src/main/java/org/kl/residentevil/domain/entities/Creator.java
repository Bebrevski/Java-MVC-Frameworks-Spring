package org.kl.residentevil.domain.entities;

public enum Creator {
    Corp, corp;
}
